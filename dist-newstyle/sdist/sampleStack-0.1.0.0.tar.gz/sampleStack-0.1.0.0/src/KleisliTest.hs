module KleisliTest () where

import Control.Arrow
import Data.Maybe
